# Midterm
The details will be given in class.